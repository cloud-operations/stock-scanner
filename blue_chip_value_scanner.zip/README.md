# Blue-Chip Value Scanner

A mobile-friendly Streamlit app that scans 50 large U.S.-listed companies and ranks
potential value opportunities.

## What it measures

Opportunity Score:

- 30% valuation
- 25% price dislocation
- 25% business quality
- 15% growth
- 5% momentum

The scanner also applies value-trap penalties for deteriorating fundamentals.

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

## Run on your phone using Streamlit Community Cloud

1. Create a GitHub repository.
2. Upload `app.py` and `requirements.txt` from this folder.
3. Go to Streamlit Community Cloud and choose **Create app / Deploy app**.
4. Select the GitHub repository and use `app.py` as the entrypoint.
5. Deploy.
6. Open the resulting Streamlit URL in Safari or Chrome on your phone.
7. On iPhone, optionally use **Share → Add to Home Screen**.

No market-data API key is required in this first version.

## Important limitation

The fair-value number is a heuristic estimate, not an intrinsic-value guarantee. It
combines normalized earnings multiple, free-cash-flow yield, and analyst mean target
when available. Financial institutions are treated differently for debt and FCF metrics.

For serious investing, add SEC filing validation, earnings-estimate revision history,
sector-relative valuation, and proper historical backtesting before relying on the score.
